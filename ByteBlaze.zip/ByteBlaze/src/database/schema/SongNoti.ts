export enum SongNotiEnum {
  Enable = "enable",
  Disable = "disable",
}

export type SongNoti = SongNotiEnum;
