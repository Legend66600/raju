export interface Setup {
  guild: string;
  enable: boolean;
  channel: string;
  playmsg: string;
  voice: string;
  category: string;
}
