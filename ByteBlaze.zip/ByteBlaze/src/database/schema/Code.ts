export interface Code {
  code: string;
  plan: string;
  expiresAt: number | "lifetime";
}
