/** @ignore */
export const metadata = {
  name: "rainlink",
  version: "1.0.0",
  github: "https://github.com/RainyXeon/ByteBlaze",
};
