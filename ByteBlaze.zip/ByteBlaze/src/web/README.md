# Warining!

ByteBlaze webserver will not use object oriented programing
