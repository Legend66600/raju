export interface Metadata {
  version: string;
  autofix: string;
  codename: string;
}
