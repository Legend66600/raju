export type SetupInfoChannel = {
  guild: string;
  enable: boolean;
  channel: string;
  statmsg: string;
  category: string;
};
