export interface ManifestInterface {
  metadata: {
    bot: {
      version: string;
      autofix: string;
      codename: string;
    };
  };
}
