export type JSON_MESSAGE = Record<string, any>;
