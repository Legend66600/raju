export type IconType = {
  play: string;
  pause: string;
  loop: string;
  shuffle: string;
  stop: string;
  skip: string;
  previous: string;
  voldown: string;
  volup: string;
  arrow_next: string;
  arrow_previous: string;
  queue: string;
  delete: string;
};
